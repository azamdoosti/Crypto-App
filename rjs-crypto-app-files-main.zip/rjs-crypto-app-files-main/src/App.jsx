function App() {
  return <h1>Crypto App</h1>;
}

export default App;
